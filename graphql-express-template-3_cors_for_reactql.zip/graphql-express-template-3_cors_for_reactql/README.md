# Template for an Express Server with GraphQL

[Watch the video to learn how it was made.](https://youtu.be/TU-jZTpCig4)
