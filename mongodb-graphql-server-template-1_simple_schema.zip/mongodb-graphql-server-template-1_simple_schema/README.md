# mongodb-graphql-server-template

[Watch the video to learn how it was made.](https://youtu.be/291i04TfGb0)
